<?php
session_start();
$db = mysqli_connect("localhost","root","","db_buku");
function e($s) { global $db; return mysql_real_escape_string($db, $s); }
function cek($level) {
    if (!isset($_SESSION['level']) $_SESSION ['level'] !=$level) {header ("Location: login.php"); exit ; }
}