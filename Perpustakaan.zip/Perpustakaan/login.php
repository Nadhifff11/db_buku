<?php
include 'koneksi.php';
$err = "";
if ($_POST) {
    $u = e($_POST['username']);
    $p = e($_POST['password']);
    $r = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM user WHERE username='$u' AND password='$p' LIMIT 1"));
    if ($r) {
        $_SESSION['id'] = $r['id'];
        $_SESSION['nama'] = $r['nama'];
        $_SESSION['level'] = $r['level'];
        header("Location: " . ($r['level'] == 'admin' ? 'admin_buku.php' : 'user.php'));
        exit;
    }
    $err = "Login gagal! Username atau password salah.";
}
?>
<h2>Login Peminjaman Buku</h2>
<p style="color:red"><?= $err ?></p>
<form method="post">
    Username: <input name="username" required><br>
    Password: <input type="password" name="password" required><br>
    <button>Login</button>
</form>
