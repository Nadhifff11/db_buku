<?php
session_start();
$db = mysqli_connect("localhost", "root", "", "db_buku"); // sesuaikan nama database
function e($s) { global $db; return mysqli_real_escape_string($db, $s); }
function cek($level) {
    if (!isset($_SESSION['level']) || $_SESSION['level'] != $level) { header("Location: login.php"); exit; }
}
