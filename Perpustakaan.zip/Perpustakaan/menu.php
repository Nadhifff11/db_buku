<p>
    Halo, <?= $_SESSION['nama'] ?> (<?= $_SESSION['level'] ?>) |
    <a href="admin_buku.php">Buku</a> |
    <a href="admin_user.php">User</a> |
    <a href="admin_pinjam.php">Peminjaman</a> |
    <a href="logout.php">Logout</a>
</p>
<hr>
