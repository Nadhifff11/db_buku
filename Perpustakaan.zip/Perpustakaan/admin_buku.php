<?php
include 'koneksi.php';
cek('admin');
include 'menu.php';

if (isset($_GET['hapus'])) {
    mysqli_query($db, "DELETE FROM buku WHERE id=" . intval($_GET['hapus']));
    header("Location: admin_buku.php"); exit;
}
if (isset($_POST['simpan'])) {
    $id = intval($_POST['id']);
    $k = e($_POST['kode']); $j = e($_POST['judul']);
    $s = intval($_POST['stok']); $kt = e($_POST['kategori']);
    if ($id) mysqli_query($db, "UPDATE buku SET kode='$k', judul='$j', stok=$s, kategori='$kt' WHERE id=$id");
    else     mysqli_query($db, "INSERT INTO buku (kode,judul,stok,kategori) VALUES ('$k','$j',$s,'$kt')");
    header("Location: admin_buku.php"); exit;
}
$ed = isset($_GET['edit']) ? mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM buku WHERE id=" . intval($_GET['edit']))) : null;
?>
<h3>Data Buku</h3>
<form method="post">
    <input type="hidden" name="id" value="<?= $ed['id'] ?? 0 ?>">
    Kode: <input name="kode" value="<?= $ed['kode'] ?? '' ?>" required>
    Judul: <input name="judul" value="<?= $ed['judul'] ?? '' ?>" required>
    Stok: <input type="number" name="stok" value="<?= $ed['stok'] ?? 0 ?>" required>
    Kategori: <input name="kategori" value="<?= $ed['kategori'] ?? '' ?>" required>
    <button name="simpan">Simpan</button>
</form>
<table border="1" cellpadding="4">
    <tr><th>Kode</th><th>Judul</th><th>Stok</th><th>Kategori</th><th>Aksi</th></tr>
    <?php $q = mysqli_query($db, "SELECT * FROM buku LIMIT 50"); while ($r = mysqli_fetch_assoc($q)) { ?>
    <tr>
        <td><?= $r['kode'] ?></td><td><?= $r['judul'] ?></td><td><?= $r['stok'] ?></td><td><?= $r['kategori'] ?></td>
        <td><a href="?edit=<?= $r['id'] ?>">Edit</a> | <a href="?hapus=<?= $r['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a></td>
    </tr>
    <?php } ?>
</table>
