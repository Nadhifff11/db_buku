<?php
include 'koneksi.php';
cek('admin');
include 'menu.php';

if (isset($_GET['hapus'])) {
    mysqli_query($db, "DELETE FROM user WHERE id=" . intval($_GET['hapus']));
    header("Location: admin_user.php"); exit;
}
if (isset($_POST['simpan'])) {
    $id = intval($_POST['id']);
    $u = e($_POST['username']); $p = e($_POST['password']);
    $n = e($_POST['nama']);     $l = e($_POST['level']);
    if ($id) mysqli_query($db, "UPDATE user SET username='$u', password='$p', nama='$n', level='$l' WHERE id=$id");
    else     mysqli_query($db, "INSERT INTO user (username,password,nama,level) VALUES ('$u','$p','$n','$l')");
    header("Location: admin_user.php"); exit;
}
$ed = isset($_GET['edit']) ? mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM user WHERE id=" . intval($_GET['edit']))) : null;
?>
<h3>Data User</h3>
<form method="post">
    <input type="hidden" name="id" value="<?= $ed['id'] ?? 0 ?>">
    Username: <input name="username" value="<?= $ed['username'] ?? '' ?>" required>
    Password: <input name="password" value="<?= $ed['password'] ?? '' ?>" required>
    Nama: <input name="nama" value="<?= $ed['nama'] ?? '' ?>" required>
    Level: <select name="level">
        <option value="admin" <?= ($ed['level'] ?? '') == 'admin' ? 'selected' : '' ?>>admin</option>
        <option value="user" <?= ($ed['level'] ?? '') == 'user' ? 'selected' : '' ?>>user</option>
    </select>
    <button name="simpan">Simpan</button>
</form>
<table border="1" cellpadding="4">
    <tr><th>ID</th><th>Username</th><th>Nama</th><th>Level</th><th>Aksi</th></tr>
    <?php $q = mysqli_query($db, "SELECT * FROM user LIMIT 50"); while ($r = mysqli_fetch_assoc($q)) { ?>
    <tr>
        <td><?= $r['id'] ?></td><td><?= $r['username'] ?></td><td><?= $r['nama'] ?></td><td><?= $r['level'] ?></td>
        <td><a href="?edit=<?= $r['id'] ?>">Edit</a> | <a href="?hapus=<?= $r['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a></td>
    </tr>
    <?php } ?>
</table>
