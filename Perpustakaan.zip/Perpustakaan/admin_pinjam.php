<?php
include 'koneksi.php';
cek('admin');
include 'menu.php';

if (isset($_GET['aksi'])) {
    $id = intval($_GET['id']);
    $p = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM pinjam WHERE id=$id"));
    if ($_GET['aksi'] == 'setuju' && $p['status'] == 'menunggu') {
        $b = mysqli_fetch_assoc(mysqli_query($db, "SELECT stok FROM buku WHERE id=" . $p['buku_id']));
        if ($b['stok'] > 0) {
            mysqli_query($db, "UPDATE pinjam SET status='dipinjam', tgl_pinjam=CURDATE() WHERE id=$id");
            mysqli_query($db, "UPDATE buku SET stok=stok-1 WHERE id=" . $p['buku_id']);
        }
    } elseif ($_GET['aksi'] == 'tolak' && $p['status'] == 'menunggu') {
        mysqli_query($db, "UPDATE pinjam SET status='ditolak' WHERE id=$id");
    } elseif ($_GET['aksi'] == 'proses' && $p['status'] == 'pengembalian') {
        // denda Rp1.000 per hari jika lebih dari 7 hari
        mysqli_query($db, "UPDATE pinjam SET status='kembali', tgl_kembali=CURDATE(),
                           denda=GREATEST(DATEDIFF(CURDATE(), tgl_pinjam)-7, 0)*1000 WHERE id=$id");
        mysqli_query($db, "UPDATE buku SET stok=stok+1 WHERE id=" . $p['buku_id']);
    }
    header("Location: admin_pinjam.php"); exit;
}
?>
<h3>Data Peminjaman</h3>
<table border="1" cellpadding="4">
    <tr><th>Peminjam</th><th>Buku</th><th>Tgl Pinjam</th><th>Tgl Kembali</th><th>Status</th><th>Denda</th><th>Aksi</th></tr>
    <?php
    $q = mysqli_query($db, "SELECT p.*, u.nama, b.judul FROM pinjam p
                            JOIN user u ON p.user_id=u.id JOIN buku b ON p.buku_id=b.id
                            ORDER BY p.id DESC LIMIT 50");
    while ($r = mysqli_fetch_assoc($q)) { ?>
    <tr>
        <td><?= $r['nama'] ?></td><td><?= $r['judul'] ?></td><td><?= $r['tgl_pinjam'] ?></td>
        <td><?= $r['tgl_kembali'] ?></td><td><?= $r['status'] ?></td><td><?= $r['denda'] ?></td>
        <td>
            <?php if ($r['status'] == 'menunggu') { ?>
                <a href="?aksi=setuju&id=<?= $r['id'] ?>">Setujui</a> | <a href="?aksi=tolak&id=<?= $r['id'] ?>">Tolak</a>
            <?php } elseif ($r['status'] == 'pengembalian') { ?>
                <a href="?aksi=proses&id=<?= $r['id'] ?>">Proses Pengembalian</a>
            <?php } ?>
        </td>
    </tr>
    <?php } ?>
</table>
