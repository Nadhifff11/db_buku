<?php
include 'koneksi.php';
cek('user');
$uid = $_SESSION['id'];

if (isset($_GET['pinjam'])) {   // ajukan peminjaman
    $b = intval($_GET['pinjam']);
    mysqli_query($db, "INSERT INTO pinjam (user_id,buku_id,tgl_pinjam,status) VALUES ($uid,$b,CURDATE(),'menunggu')");
    header("Location: user.php"); exit;
}
if (isset($_GET['kembali'])) {  // ajukan pengembalian
    mysqli_query($db, "UPDATE pinjam SET status='pengembalian' WHERE id=" . intval($_GET['kembali']) . " AND user_id=$uid AND status='dipinjam'");
    header("Location: user.php"); exit;
}
?>
<p>Halo, <?= $_SESSION['nama'] ?> (user) | <a href="logout.php">Logout</a></p>
<hr>
<h3>Daftar Buku</h3>
<table border="1" cellpadding="4">
    <tr><th>Kode</th><th>Judul</th><th>Stok</th><th>Kategori</th><th>Aksi</th></tr>
    <?php $q = mysqli_query($db, "SELECT * FROM buku LIMIT 50"); while ($r = mysqli_fetch_assoc($q)) { ?>
    <tr>
        <td><?= $r['kode'] ?></td><td><?= $r['judul'] ?></td><td><?= $r['stok'] ?></td><td><?= $r['kategori'] ?></td>
        <td><?php if ($r['stok'] > 0) { ?><a href="?pinjam=<?= $r['id'] ?>">Ajukan Pinjam</a><?php } else echo "Habis"; ?></td>
    </tr>
    <?php } ?>
</table>

<h3>Peminjaman Saya</h3>
<table border="1" cellpadding="4">
    <tr><th>Buku</th><th>Tgl Pinjam</th><th>Tgl Kembali</th><th>Status</th><th>Denda</th><th>Aksi</th></tr>
    <?php
    $q = mysqli_query($db, "SELECT p.*, b.judul FROM pinjam p JOIN buku b ON p.buku_id=b.id
                            WHERE p.user_id=$uid ORDER BY p.id DESC LIMIT 50");
    while ($r = mysqli_fetch_assoc($q)) { ?>
    <tr>
        <td><?= $r['judul'] ?></td><td><?= $r['tgl_pinjam'] ?></td><td><?= $r['tgl_kembali'] ?></td>
        <td><?= $r['status'] ?></td><td><?= $r['denda'] ?></td>
        <td><?php if ($r['status'] == 'dipinjam') { ?><a href="?kembali=<?= $r['id'] ?>">Kembalikan</a><?php } ?></td>
    </tr>
    <?php } ?>
</table>
